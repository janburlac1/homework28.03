public class Students {
    private String name;
    private int group;
    public Students(String name){
        this.name = name;
    }
    public Students(String name, int group){
        this(name);
        this.group = group;

    }
    public Students (Students studentsnew){
        this.name = studentsnew.name;
        this.group = studentsnew.group;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getGroup() {
        return group;
    }

    public void setGroup(int group) {
        this.group = group;
    }
}
