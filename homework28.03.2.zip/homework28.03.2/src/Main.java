public class Main {
    public static void main(String[] args) {
        Students student1 = new Students("Aliosa",1);
        Students student2 = student1;
        Students student3 = new Students(student1);
        student1.setName("Grisa");
        System.out.println(student1.getName() +  student1.getGroup());
        System.out.println(student2.getName() +  student2.getGroup());
        System.out.println(student3.getName() +  student3.getGroup());
    }
}