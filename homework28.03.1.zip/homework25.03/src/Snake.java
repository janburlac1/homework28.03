public enum Snake {
    BOUNTY, SNIKERS, TWIX, KITKAT
}
