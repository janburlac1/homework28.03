import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        System.out.println("vedite nomer sladosti: ");
        int numberSnake = scn.nextInt();
        if (numberSnake == 1){
            System.out.println(Snake.BOUNTY);
        }
        if (numberSnake == 2){
            System.out.println(Snake.SNIKERS);
        }
        if (numberSnake == 3){
            System.out.println(Snake.TWIX);
        }
        if (numberSnake == 4){
            System.out.println(Snake.KITKAT);
        }

    }
}